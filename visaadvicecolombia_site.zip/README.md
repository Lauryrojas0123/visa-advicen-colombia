
Visa Advice Colombia — Paquete listo para desplegar
--------------------------------------------------

Contenido:
- frontend/    -> Vite + React frontend. Reemplaza imágenes en public/images.
- backend/     -> Express backend con endpoint /api/leads que puede appender a Google Sheets usando service account.
- apps_script/ -> Google Apps Script alternative to receive POST and append to Sheets.
- visaadvicecolombia_site.zip -> This zip (download from root of package)

Instrucciones rápidas:
1. Edita frontend/public/images with real images from your brochure.
2. Deploy backend on a server (Heroku, Render, VPS) and set environment variables from backend/.env.example.
3. Deploy frontend (Vercel, Netlify) and configure rewrite/proxy to send /api/leads to the backend base URL, OR host both together on the same server.
4. To use Google Sheets: either use service account (backend) or deploy Apps Script and point frontend to that webhook.

If you want, I can:
- Customize the repo to your hosting (Netlify/Vercel) specifics.
- Pre-fill the Google Apps Script with your sheet ID (you must provide it or grant access).
