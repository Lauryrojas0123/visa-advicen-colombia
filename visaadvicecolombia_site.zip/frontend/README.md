
# Frontend (Vite + React) - Visa Advice Colombia

## Setup
1. `cd frontend`
2. `npm install`
3. `npm run dev`

## Build
`npm run build` will create a `dist/` folder to serve statically.

## Notes
- Place your brochure images in `public/images/` replacing the placeholder files.
- The frontend posts leads to `/api/leads` (relative). When deploying together with the backend, the proxy will handle it.
