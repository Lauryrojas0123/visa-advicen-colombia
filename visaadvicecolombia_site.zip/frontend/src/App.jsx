import React, { useMemo, useState } from "react";

const WHATSAPP = "573228394758";
const SUPPORT_EMAIL = "contacto@visaadvicecolombia.com.co";

function toGoogleDateTime(dt) {
  const pad = n => String(n).padStart(2,"0");
  const yyyy = dt.getUTCFullYear();
  const mm = pad(dt.getUTCMonth()+1);
  const dd = pad(dt.getUTCDate());
  const HH = pad(dt.getUTCHours());
  const MM = pad(dt.getUTCMinutes());
  const SS = pad(dt.getUTCSeconds());
  return `${yyyy}${mm}${dd}T${HH}${MM}${SS}Z`;
}
function buildGCalLink({ startLocalISO, durationMin=30 }) {
  const start = new Date(startLocalISO);
  const end = new Date(start.getTime() + durationMin*60000);
  const dates = `${toGoogleDateTime(start)}/${toGoogleDateTime(end)}`;
  const text = encodeURIComponent("Asesoría migratoria – Visa Advice Colombia");
  const details = encodeURIComponent("Cita virtual de diagnóstico y orientación de visado.");
  const location = encodeURIComponent("Google Meet / WhatsApp");
  return `https://calendar.google.com/calendar/render?action=TEMPLATE&text=${text}&details=${details}&dates=${dates}&location=${location}`;
}

export default function App(){
  const [data,setData] = useState({nombre:"",telefono:"",correo:"",ciudad:""});
  const [sent,setSent] = useState(false);
  const [date,setDate] = useState("");
  const [time,setTime] = useState("");
  const [dur,setDur] = useState(30);

  const update = k => e => setData(d=>({...d,[k]:e.target.value}));

  const valid = useMemo(()=> {
    const emailOk = /.+@.+\..+/.test(data.correo.trim());
    const phoneOk = /^(\+?\d{7,15})$/.test(data.telefono.replace(/\s|-/g,""));
    return data.nombre.trim().length>2 && emailOk && phoneOk && data.ciudad.trim().length>1;
  },[data]);

  const submit = async () => {
    if(!valid) return;
    // send to backend
    try{
      const resp = await fetch("/api/leads", {
        method:"POST",
        headers:{"Content-Type":"application/json"},
        body: JSON.stringify({...data, source: "web"})
      });
      if(!resp.ok) throw new Error("No se pudo enviar");
    }catch(e){
      console.warn("backend error", e);
      // fallback: still open mailto
    }
    // open mailto
    const subject = encodeURIComponent("Nuevo interesado – Visa Advice Colombia");
    const body = encodeURIComponent(
      `Nombre: ${data.nombre}\nTeléfono: ${data.telefono}\nCorreo: ${data.correo}\nCiudad: ${data.ciudad}\nFecha: ${new Date().toLocaleString()}`
    );
    window.open(`mailto:${SUPPORT_EMAIL}?subject=${subject}&body=${body}`, "_blank");
    setSent(true);
  };

  const openGCal = () => {
    if(!date||!time) return;
    const iso = `${date}T${time}:00`;
    const link = buildGCalLink({startLocalISO: iso, durationMin: Number(dur)});
    window.open(link, "_blank");
  };

  return (
    <div>
      <header className="card container" style={{marginTop:16, display:"flex", justifyContent:"space-between", alignItems:"center"}}>
        <div>
          <div style={{fontWeight:800}}>Visa Advice Colombia</div>
          <div style={{fontSize:12,color:"#6b7280"}}>www.visaadvicecolombia.com.co</div>
        </div>
        <nav style={{display:"flex",gap:12}}>
          <a href="#uk">UK</a>
          <a href="#usa">USA</a>
          <a href="#agenda">Agenda</a>
        </nav>
      </header>

      <main className="container" style={{marginTop:24}}>
        <section className="card" style={{padding:24}}>
          <h1>Trámite Visa Reino Unido - Desde Colombia</h1>
          <p>Asesoría integral, revisión documental y agendamiento. Tarifas de servicio: Adulto $504.790, Menores $324.560</p>
        </section>

        <section id="agenda" className="card" style={{marginTop:16}}>
          <h3>Agenda tu cita (Google Calendar)</h3>
          <div style={{display:"flex",gap:8,flexWrap:"wrap"}}>
            <input className="input" type="date" value={date} onChange={e=>setDate(e.target.value)} />
            <input className="input" type="time" value={time} onChange={e=>setTime(e.target.value)} />
            <select className="input" value={dur} onChange={e=>setDur(e.target.value)}>
              <option value={15}>15 min</option>
              <option value={30}>30 min</option>
              <option value={45}>45 min</option>
              <option value={60}>60 min</option>
            </select>
            <button className="btn" onClick={openGCal}>Programar en Google Calendar</button>
          </div>
        </section>

        <section id="contact" className="card" style={{marginTop:16}}>
          <h3>Déjanos tus datos</h3>
          <div style={{display:"grid",gap:8,maxWidth:520}}>
            <input className="input" placeholder="Nombre" value={data.nombre} onChange={update("nombre")} />
            <input className="input" placeholder="Teléfono (ej: 5731...)" value={data.telefono} onChange={update("telefono")} />
            <input className="input" placeholder="Correo" value={data.correo} onChange={update("correo")} />
            <input className="input" placeholder="Ciudad" value={data.ciudad} onChange={update("ciudad")} />
            <div style={{display:"flex",gap:8}}>
              <button className="btn" onClick={submit} disabled={!valid}>{sent? "Enviado":"Enviar"}</button>
              <a className="btn" style={{background:"#25D366"}} href={`https://wa.me/${WHATSAPP}?text=${encodeURIComponent(`Hola, soy ${data.nombre||""} y estoy interesado(a) en asesoría de visa. Tel: ${data.telefono||""}. Ciudad: ${data.ciudad||""}.`)}`} target="_blank" rel="noreferrer">WhatsApp</a>
            </div>
            {sent && <div style={{color:"#15803d"}}>Gracias — hemos recibido tu solicitud.</div>}
          </div>
        </section>

      </main>

      <footer className="container" style={{marginTop:24, marginBottom:40}}>
        <div style={{display:"flex",justifyContent:"space-between",alignItems:"center"}}>
          <div>© {new Date().getFullYear()} Visa Advice Colombia</div>
          <div>contacto@visaadvicecolombia.com.co • +{WHATSAPP}</div>
        </div>
      </footer>
    </div>
  )
}
