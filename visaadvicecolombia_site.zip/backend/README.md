
# Backend (Express) - Visa Advice Colombia

## Setup
1. `cd backend`
2. `npm install`
3. Create a Google Cloud Service Account and enable Google Sheets API OR use the Apps Script webhook alternative.

### Option A - Service Account (recommended for server deployments)
- Share your Google Sheet with the service account's client_email.
- Place the service account JSON file as `backend/service-account.json`.
- Set `.env`:
  ```
  SHEETS_ENABLED=true
  SHEET_ID=<your-sheet-id>
  ```
- Start server: `npm start`
- The endpoint `/api/leads` accepts POST with JSON: `{ nombre, telefono, correo, ciudad, source }`

### Option B - Google Apps Script Webhook (no server required)
Use the provided Apps Script in `/apps_script` to create a simple webhook. Deploy it as a Web App and set `SHEETS_ENABLED=false` in the backend or point the frontend to the Apps Script URL.

