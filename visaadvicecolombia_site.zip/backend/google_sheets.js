/**
 * google_sheets.js
 * Uses a Google Service Account JSON key to authenticate and append rows to a spreadsheet.
 *
 * Setup:
 * 1) Create a Google Cloud service account and grant it access to Google Sheets API.
 * 2) Share the target Google Sheet with the service account's client_email.
 * 3) Download the service account JSON and place it as 'service-account.json' in this folder.
 * 4) Set environment variables:
 *    - SHEETS_ENABLED=true
 *    - SHEET_ID=<your-sheet-id>
 *
 * NOTE: Do NOT commit your service-account.json to public repos.
 */

const { google } = require('googleapis');
const path = require('path');
const fs = require('fs');

async function getAuthClient(){
  const keyPath = path.join(__dirname, 'service-account.json');
  if(!fs.existsSync(keyPath)) throw new Error('service-account.json not found. Follow README to create it.');
  const auth = new google.auth.GoogleAuth({
    keyFile: keyPath,
    scopes: ['https://www.googleapis.com/auth/spreadsheets']
  });
  return await auth.getClient();
}

async function appendToSheet(sheetId, row){
  const authClient = await getAuthClient();
  const sheets = google.sheets({version:'v4', auth: authClient});
  const resource = { values: [ row ] };
  await sheets.spreadsheets.values.append({
    spreadsheetId: sheetId,
    range: 'Sheet1!A:F',
    valueInputOption: 'USER_ENTERED',
    resource
  });
}

module.exports = { appendToSheet };
