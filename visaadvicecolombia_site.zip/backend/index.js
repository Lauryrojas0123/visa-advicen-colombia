require('dotenv').config();
const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const { appendToSheet } = require('./google_sheets');

const app = express();
app.use(cors());
app.use(bodyParser.json());

app.post('/api/leads', async (req, res) => {
  try {
    const lead = req.body;
    // expected: { nombre, telefono, correo, ciudad, source }
    if(!lead || !lead.nombre) return res.status(400).json({error:'invalid'});
    const row = [
      new Date().toISOString(),
      lead.nombre || '',
      lead.telefono || '',
      lead.correo || '',
      lead.ciudad || '',
      lead.source || 'web'
    ];
    // Append to Google Sheet if configured
    if(process.env.SHEETS_ENABLED === 'true') {
      await appendToSheet(process.env.SHEET_ID, row);
    } else {
      console.log('SHEETS_DISABLED - lead:', row);
    }
    return res.status(200).json({ok:true});
  } catch(err){
    console.error(err);
    return res.status(500).json({error:'server_error'});
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, ()=> console.log('Backend listening on', PORT));
